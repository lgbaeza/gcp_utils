#import pandas as pd --

def get_indices(es_client):
    indices = es_client.indices.get(index="*,-.*")
    user_created_indices = []
    for index in indices:
        if not index.startswith("."):
            user_created_indices.append({
                "index": index,
                "shards": indices[index]["settings"]["index"]["number_of_shards"],
                "creation_date": indices[index]["settings"]["index"]["creation_date"],
                "blocks_write": ""#indices[index]["settings"]["index"]["blocks"]["write"],
            })
    return user_created_indices

"""
def get_index_sample(es_client, index_name, size=SAMPLE_SIZE):
    search_result = es_client.search(
        index=index_name,
        body={"query": {"match_all": {}}, "size": size}
    )

    # Extract documents
    documents = search_result['hits']['hits']
    documents_return = [doc['_source'] for doc in documents]
    return pd.DataFrame(documents_return)
"""

def get_index_mapping(es_client, index_name):
    mappings = es_client.indices.get_mapping(index=index_name)
    mappings_output = []
    print(mappings)
    for index_name, index_mapping in mappings.items():
        for field_name, field_mapping in index_mapping['mappings']['properties'].items():
            mappings_output.append({
                "index_name": index_name,
                "field_name": field_name,
                "type": field_mapping["type"]
            })
    return mappings_output