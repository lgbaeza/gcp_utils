from google.cloud import dataplex_v1
import time

def dataplex_elastic_setup(dplx_client, GCP_PROJECT_ID,
                            parent_project, entry_group_id, 
                           entry_type_id, entry_type_name, 
                           type_system, type_display, type_description,
                          aspect_type_id):
    
    # Aspect type
    attribute_fields = dataplex_v1.types.AspectType.MetadataTemplate(
        name = "Attribute",
        type_ = "record",
        index = 1,
        constraints = dataplex_v1.types.AspectType.MetadataTemplate.Constraints(required=True),
        record_fields = [
            dataplex_v1.types.AspectType.MetadataTemplate(
                name = "Name",
                type_ = "string",
                index = 1,
                constraints = dataplex_v1.types.AspectType.MetadataTemplate.Constraints(required=True)
            ),
            dataplex_v1.types.AspectType.MetadataTemplate(
                name = "DataType",
                type_ = "string",
                index = 2,
                constraints = dataplex_v1.types.AspectType.MetadataTemplate.Constraints(required=True)
            )
        ]
    )

    index_fields = [
        dataplex_v1.types.AspectType.MetadataTemplate(
            name = "Attributes",
            type_ = "array",
            index = 1,
            constraints = dataplex_v1.types.AspectType.MetadataTemplate.Constraints(required=True),
            array_items = attribute_fields
        ),
        dataplex_v1.types.AspectType.MetadataTemplate(
            name = "Shards",
            type_ = "string",
            index = 2,
            constraints = dataplex_v1.types.AspectType.MetadataTemplate.Constraints(required=True),
        ),
        dataplex_v1.types.AspectType.MetadataTemplate(
            name = "CreationDate",
            type_ = "string",
            index = 3,
            constraints = dataplex_v1.types.AspectType.MetadataTemplate.Constraints(required=True),
        ),
        dataplex_v1.types.AspectType.MetadataTemplate(
            name = "BlocksWrite",
            type_ = "string",
            index = 4,
            constraints = dataplex_v1.types.AspectType.MetadataTemplate.Constraints(required=True),
        )
    ]

    aspect_type = dataplex_v1.types.AspectType(
        metadata_template = dataplex_v1.types.AspectType.MetadataTemplate(
            name = "Index",
            type_ = "record",
            record_fields = index_fields
        )
    )

    try:
        dplx_client.create_aspect_type(
            parent = f"projects/{GCP_PROJECT_ID}/locations/global",
            aspect_type_id = aspect_type_id,
            aspect_type = aspect_type
        )
        time.sleep(2)
    except Exception as ex:
        print("Aspect Type exists, skipping...")
        print(ex)

    
    # Entry Group - Container for indexes
    entry_group = dataplex_v1.types.EntryGroup(
        description = type_description
    )
    
    try:
        dplx_client.create_entry_group(
            parent = parent_project,
            entry_group_id = entry_group_id,
            entry_group = entry_group
        )
        time.sleep(2)
    except Exception as ex:
        print("Entry Group exists, skipping...")
        print(ex)
    
    
    # Entry type, to map an index into the catalog
    entry_type_id = entry_type_id
    entry_type = dataplex_v1.types.EntryType(
        type_aliases = ["TABLE"],
        display_name = type_display,
        system = type_system,
        description = type_description,
        required_aspects = [
            dataplex_v1.types.EntryType.AspectInfo(
                type_=f"projects/{GCP_PROJECT_ID}/locations/global/aspectTypes/{aspect_type_id}"
        )]
    )

    try:
        dplx_client.create_entry_type(
            entry_type = entry_type,
            parent = f"projects/{GCP_PROJECT_ID}/locations/global",
            entry_type_id = entry_type_id
        )
        time.sleep(2)
    except Exception as ex:
        print("Entry Type exists, skipping...")
        print(ex)

def get_current_entries(dplx_client, parent_group):
    current_dplx_entries = []
    for entry in dplx_client.list_entries(parent=parent_group):
        if entry.entry_type[entry.entry_type.rindex("/")+1:] != "entrygroup":
            entry_id = entry.name[entry.name.rindex("/")+1:]
            current_dplx_entries.append(entry_id)
            
    return current_dplx_entries

def create_dataplex_entry(dplx_client, GCP_PROJECT_ID, entry_id, aspects, system, description, entry_type_id, parent_group):
    entry_name = f"elasticsearch.cloud.es/{entry_id}"

    entry_source = dataplex_v1.types.EntrySource(
        system = system,
        display_name = entry_id,
        description = description
    )
    
    entry = dataplex_v1.types.Entry(
        name = entry_id,
        entry_type = f"projects/{GCP_PROJECT_ID}/locations/global/entryTypes/{entry_type_id}",
        entry_source = entry_source,
        aspects = aspects
    )
    
    try:
        dplx_client.create_entry(
            parent = parent_group,
            entry_id = entry_name,
            entry = entry
        )
    except Exception as ex:
        print(f"Entry {entry_id} exists, skipping...")
        print(ex)