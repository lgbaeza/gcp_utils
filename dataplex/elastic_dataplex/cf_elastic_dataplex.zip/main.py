import functions_framework
import time
import google.protobuf
from google.cloud import dataplex_v1
from elasticsearch import Elasticsearch
import os
#import pandas as pd --

# Elastic connection and config
ES_ENDPOINT = os.environ['ES_ENDPOINT']
ES_API_KEY_ID = os.environ['ES_API_KEY_ID']
ES_API_KEY = os.environ['ES_API_KEY']
SAMPLE_SIZE = 5

### Project information
GCP_PROJECT_ID = os.environ['GCP_PROJECT_ID']
GCP_LOCATION_ID = os.environ['GCP_LOCATION_ID']

### Constants for Dataplex Catalog
DATAPLEX_GROUP_ID = "elasticsearch"
DATAPLEX_ENTRY_TYPE_ID = "elasticsearch-index"
DATAPLEX_ENTRY_TYPE_NAME = "Elasticsearch Index"
DATAPLEX_SYSTEM = "Elasticsearch"
DATAPLEX_TYPE_DISPLAY = "Elasticsearch index"
DATAPLEX_TYPE_DESCRIPTION = ES_ENDPOINT
DATAPLEX_ASPECT_TYPE_ID = "index-schema"

parent_project = f"projects/{GCP_PROJECT_ID}/locations/{GCP_LOCATION_ID}"
parent_group = f"projects/{GCP_PROJECT_ID}/locations/{GCP_LOCATION_ID}/entryGroups/{DATAPLEX_GROUP_ID}"

### Service clients
es_client = Elasticsearch(
    [ES_ENDPOINT],
    api_key=(ES_API_KEY_ID, ES_API_KEY),
    verify_certs=True 
)
dplx_client = dataplex_v1.CatalogServiceClient()

### Utility methods
import dataplex_utils as dataplex_utils
import elastic_utils as elastic_utils

@functions_framework.http
def main(request):

    ### Initial setup to create group, entry type and aspect
    print("##### Running initial Dataplex Elastic Setup #####")
    dataplex_utils.dataplex_elastic_setup(dplx_client=dplx_client, GCP_PROJECT_ID=GCP_PROJECT_ID, 
        parent_project=parent_project, entry_group_id=DATAPLEX_GROUP_ID, 
        entry_type_id=DATAPLEX_ENTRY_TYPE_ID, entry_type_name=DATAPLEX_ENTRY_TYPE_NAME,
        type_system=DATAPLEX_SYSTEM, type_display=DATAPLEX_TYPE_DISPLAY,
        type_description=DATAPLEX_TYPE_DESCRIPTION, 
        aspect_type_id=DATAPLEX_ASPECT_TYPE_ID)
    print("##### Initial Dataplex Elastic setup finished #####")
    

    ### Get entries, if they already exists
    current_dplx_entries = dataplex_utils.get_current_entries(dplx_client=dplx_client, parent_group=parent_group)
    print("##### Current Dataplex entries: #####")
    print(current_dplx_entries)

    ### Get Elasticsearch indices
    indices = elastic_utils.get_indices(es_client=es_client)
    print("##### Current ES indices: #####")
    print(indices)

    ### Ingest into Dataplex Catalog
    for index in indices:
        index_name = index["index"]
        schema = google.protobuf.struct_pb2.ListValue()
        attributes = elastic_utils.get_index_mapping(es_client=es_client, index_name=index_name)
        for attr in attributes:
            col = google.protobuf.struct_pb2.Struct()
            col["Name"] = attr["field_name"]
            col["DataType"] = attr["type"]
            schema.append(col)
        
        aspect_data = google.protobuf.struct_pb2.Struct()
        aspect_data["Attributes"] = schema
        aspect_data["Shards"] = index["shards"]
        aspect_data["CreationDate"] = index["creation_date"]
        aspect_data["BlocksWrite"] = index["blocks_write"]
        
        aspect_data = dataplex_v1.types.Aspect(data = aspect_data)
        aspects = {f"{GCP_PROJECT_ID}.global.{DATAPLEX_ASPECT_TYPE_ID}": aspect_data}
        
        if index_name not in current_dplx_entries:
            print(f"##### Index {index_name} ingested as Dataplex Entry #####")
            dataplex_utils.create_dataplex_entry(dplx_client=dplx_client, GCP_PROJECT_ID=GCP_PROJECT_ID,
                                entry_id=index_name, aspects=aspects,
                                system=DATAPLEX_SYSTEM, 
                                description=index["creation_date"],
                                entry_type_id=DATAPLEX_ENTRY_TYPE_ID, parent_group=parent_group)
            current_dplx_entries.append(index_name)
        else:
            print(f"##### Index {index_name} existis, skipping... #####")


    return "Sync completed!"
